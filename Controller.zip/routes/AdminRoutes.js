// const express = require("express");
// const router = new express.Router();
// const Admin = require('../Modal/Admin')
// const User = require('../Modal/Student')
// const Enrollment = require('../Modal/Enrollment')
// const jwt = require('jsonwebtoken')
// const Course = require('../Modal/Course')

// //==========    ======================== Admin Login Page =============================   ============ //

// router.post('/api/admin/login', async (req, res) => {
//   const {email , password} = req.body
//   console.log(email , password , " data from postman ")
//     try {
//         const user = await Admin.findOne({ email: email })

//          const isPassword = await Admin.findOne({password : password})
//          console.log(isPassword , "is password ")
//         if (!user) {
//             res.status(401).json({ message: 'Invalid login credentials' });

//         } else {
//             const UserResponse = {
//                 user: user._id,
//                 email: user.email,

//             }
//             const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
//             res.cookie("access-token", token, {
//                 httpOnly: true,
//                 sameSite: "None"
//             }).status(200).json({ message: "Hey Admin ! You have logged in successfully", UserResponse });
//         }
//     } catch (error) {
//         console.log(error)
//     }
// })



// //==========    ======================== Admin Registration Page =============================   ============ //
// router.post('/api/admin/register', (req, res) => {

//     const { email, Branch, Password, mobile, Gender, isHod } = req.body;

//     try {
//         const savedUser = new Admin({
//             email,

//             Password,
//             isAdmin: true

//         });

//         savedUser.save();

//         res.status(200).json('Registered Successfully')
//     } catch (err) {
//         res.status(500).json(err)
//     }
// })





// //==========    ======================== Admin New Registration  Page API=============================   ============ //


// router.get('/api/admin/newregistrations', async (req, res) => {

//     try {

//         const students = await User.find();
//         const approvedStudents = students.filter(student => student.isApproved === false);
//         // console.log(approvedStudents)
//         res.status(200).json({ students: approvedStudents });
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ message: 'Internal Server Error' });
//     }
// })

// //==========    ======================== Admin Enrollment API  =============================   ============ //
// router.get('/api/admin/enrollment', async (req, res) => {

//     try {
//         const students = await User.find();
//         const approvedStudents = students.filter(student => student.isEnrolled === false && student.isApproved === true);

//         res.status(200).json({ students: approvedStudents });
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ message: 'Internal Server Error' });
//     }

// })













// router.get('/api/v2/newenrollmentrequest', async (req, res) => {
//   try {
//     const { courseType, courseName,   courseBranch, assignedCollege } = req.query;
//     console.log( courseType,
//       courseName,
//       courseBranch,
//       assignedCollege , "data from query ")
//     const students = await User.find({
//        courseType,
//        courseName,
//        courseBranch,
//        assignedCollege,
//         IsEnrollGenerated: true,
//        isPaid:true
//     });
//     console.log(students)
//     res.status(200).json(students);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });









// // router.get('/getcode',async(req,res)=>{
// //   const { collegename, coursename, branchname } = req.body;
// //   console.log(collegename, coursename , branchname , "data from postman")
// //  const colcode =  await findCollegeCodeByName(collegename)
// //  const cocode = await findCourseCodeByName(coursename)
// //   const bcode = await findBranchCodeByName(branchname)
// //   console.log(colcode , cocode ,bcode)
// //   res.json({colcode , cocode , bcode})
// // })


















// const CURRENT_YEAR = new Date().getFullYear() % 100;
// router.post('/generate-enrollment', async (req, res) => {
//     const { collegeCode, courseCode, branchCode, level  , studentId} = req.body;
//     const currentYearLastTwoDigits = CURRENT_YEAR.toString().padStart(2, '0');

//     try {
//         const existingEnrollment = await User.findOne({ _id: studentId, IsEnrollGenerated:true});
//         console.log(existingEnrollment)
//         if (existingEnrollment) {
//           return res.status(400).json({ error: 'Enrollment already generated for this student' });
//         }
//       // Find or create enrollment document in the database
//       const enrollment = await Enrollment.findOneAndUpdate(
//         { collegeCode, courseCode, branchCode, level },
//         {},
//         { upsert: true, new: true }
//       );

//       // Increment and save the sequence number
//       const sequenceNumber = enrollment.sequenceNumber;
//       enrollment.sequenceNumber += 1;
//       await enrollment.save();

//       // Create and return the enrollment number
//       const enrollmentNumber = `${currentYearLastTwoDigits}${collegeCode}${courseCode}${branchCode}${level}${sequenceNumber.toString().padStart(3, '0')}`;
//       console.log(enrollmentNumber)
//       const updatedStudent =  await User.findOneAndUpdate(
//         { _id:studentId },
//         {  randomId:enrollmentNumber},
//         {  IsEnrollGenerated:true},
//         { new: true }
//       );
//       console.log(updatedStudent , "updated student ")
//       res.json({ enrollmentNumber });

//     } catch (error) {
//       console.error(error);
//       res.status(500).json({ error: 'Internal Server Error' });
//     }
//   });



//   const findCollegeCodeByName = async (collegename) => {
//     const college = await Course.findOne({"institute.name" : collegename  });
//     return college ? college.institute.code : null;
//   };


//   const findCourseCodeByName = async (coursename) => {
//     const course = await Course.findOne({ name:coursename });
//     return course ? course.institute.code : null;
//   };

//   // Function to find branch code by name
//   const findBranchCodeByName = async (branchname) => {
//     const branch = await Course.findOne({ "branches.name": branchname });
//     return branch ?  branch.branches[0].code : null;
//   };



// router.post('/generate-enrollment2', async (req, res) => {
//     const { collegename, coursename, branchname , studentId} = req.body;
//     console.log(collegename , coursename , branchname , "kafirana sa hai ")
//     const level  = 3
//     const collegeCode =  await findCollegeCodeByName(collegename)
//     const courseCode = await findCourseCodeByName(coursename)
//     const branchCode = await findBranchCodeByName(branchname)
//     console.log("data for code ", collegeCode , courseCode , branchCode)
//     const currentYearLastTwoDigits = CURRENT_YEAR.toString().padStart(2, '0');

//     try {
//         const existingEnrollment = await User.findOne({ _id: studentId, IsEnrollGenerated:true});
//         //console.log(existingEnrollment)
//         if (existingEnrollment) {
//           return res.status(400).json({ error: 'Enrollment already generated for this student' });
//         }
//       // Find or create enrollment document in the database
//       const enrollment = await Enrollment.findOneAndUpdate(
//         { collegeCode, courseCode, branchCode, level },
//         {},
//         { upsert: true, new: true }
//       );

//       // Increment and save the sequence number
//       const sequenceNumber = enrollment.sequenceNumber;
//       enrollment.sequenceNumber += 1;
//       await enrollment.save();

//       // Create and return the enrollment number
//       const enrollmentNumber = `${currentYearLastTwoDigits}${collegeCode}${courseCode}${branchCode}${level}${sequenceNumber.toString().padStart(3, '0')}`;
//       console.log(enrollmentNumber)
//       const updatedStudent =  await User.findOneAndUpdate(
//         { _id:studentId },
//         {  randomId:enrollmentNumber, IsEnrollGenerated:true},

//         { new: true }
//       );
//       //console.log(updatedStudent , "updated student ")
//       res.json({ enrollmentNumber });

//     } catch (error) {
//       console.error(error);
//       res.status(500).json({ error: 'Internal Server Error' });
//     }
//   });














//  


//   // router.get('/getcodes', async (req, res) => {
//   //   try {
//   //     const { name } = req.body;
//   //    console.log(name ,"course name ")
//   //     // Check if the course with the given name already exists
//   //     const foundCourse = await Course.findOne({ name });

//   //     if (!foundCourse) {
//   //       return res.status(404).json({ error: 'Course not found' });
//   //     }

//   //     res.status(200).json({ foundCourse });
//   //   } catch (error) {
//   //     console.error(error);
//   //     res.status(500).json({ error: 'Internal Server Error' });
//   //   }
//   // });

// module.exports = router

const express = require("express");
const router = new express.Router();
const Admin = require('../Modal/Admin')
const User = require('../Modal/Student')
const Enrollment = require('../Modal/Enrollment')
const jwt = require('jsonwebtoken')
const Course = require('../Modal/Course')
const NCourse = require('../Modal/NCourse')
const nodemailer = require("nodemailer");
//==========    ======================== Admin Login Page =============================   ============ //

router.post('/api/admin/login', async (req, res) => {
  const { email, password } = req.body
  //console.log(email , password , " data from postman ")
  try {
    const user = await Admin.findOne({ email: email })

    const isPassword = await Admin.findOne({ password: password })
    //console.log(isPassword , "is password ")
    if (!user) {
      res.status(401).json({ message: 'Invalid login credentials' });

    } else {
      const UserResponse = {
        user: user._id,
        email: user.email,
      }
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      res.cookie("accessToken", token, {
        httpOnly: true,
        sameSite: "None"
      }).status(200).json({ message: "Hey Admin ! You have logged in successfully", UserResponse });
    }
  } catch (error) {
    console.log(error)
  }
})


// router.get('/api/admin/zero', async (req,res)=>{
//     res.json("chal raha ye to ")
// })

//==========    ======================== Admin Registration Page =============================   ============ //
router.post('/api/admin/register', (req, res) => {

  const { email, Branch, Password, mobile, Gender, isHod } = req.body;

  try {
    const savedUser = new Admin({
      email,

      Password,
      isAdmin: true

    });

    savedUser.save();

    res.status(200).json('Registered Successfully')
  } catch (err) {
    res.status(500).json(err)
  }
})





//==========    ======================== Admin New Registration  Page API=============================   ============ //


// router.get('/api/admin/newregistrations', async (req, res) => {

//   try {

//     const students = await User.find();
//     const approvedStudents = students.filter(student => student.isApproved === false);
//     // console.log(approvedStudents)
//     res.status(200).json({ students: approvedStudents });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// })

//+============================================= Admin API   New Registration ===============================================//




router.get('/api/admin/newregistered', async (req, res) => {

  try {
    const students = await User.find({
      isRegistered: true,
      isPaid: false,
      isApproved: false,
      isEnrolled: false
    });

    res.status(200).json({ students });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }

});










//+============================================= Admin API   New Registration ============================
router.get('/api/admin/searchapi ', async(req,res)=>{
  const query = req.query.query;
  
  try {
    const results = await User.find({
      $or: [
        { randomId: { $regex: query, $options: 'i' } },
        { name: { $regex: query, $options: 'i' } },
        { email: { $regex: query, $options: 'i' } },
       
      ],
    });

    res.json(results);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
})





//==========    ======================== Admin Enrollment API  =============================   ============ //
router.get('/api/admin/enrollment', async (req, res) => {

  try {
    const students = await User.find();
    const approvedStudents = students.filter(student => student.isEnrolled === false && student.isApproved === true);

    res.status(200).json({ students: approvedStudents });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }

})








//Enrollment request student's data 

router.get('/api/v2/newenrollmentrequest', async (req, res) => {
  try {
    const { session, courseType, course, branch, college } = req.query;
    console.log(courseType,
      course,
      branch,
      college, "data from query ")
    const students = await User.find({

      admissionSession: session,
      courseType,
      courseName: course,
      courseBranch: branch,
      assignedCollege: college,
      IsEnrollGenerated: false,
      isPaid: true
    });
    console.log(students)
    res.status(200).json(students);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



router.get('/api/v2/listofenrolledstudent', async (req, res) => {
  try {
    const { session, courseType, course, branch, college } = req.query;
    console.log(courseType,
      course,
      branch,
      college, "data from query ")
    const students = await User.find({

      admissionSession: session,
      courseType,
      courseName: course,
      courseBranch: branch,
      assignedCollege: college,
      IsEnrollGenerated: true,
      isPaid: true
    });
    console.log(students)
    res.status(200).json(students);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



router.get('/apitest/students/today/count', async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
    console.log(today)
  try {
    const count = await User.countDocuments({
      createdAt: { $gte: today },

    });
    const Totalcount = await User.countDocuments({
    });
    const paidStudentCount = await User.countDocuments({
      isPaid: true,
    });
    const TotalEnrolled = await User.countDocuments({
      isEnrolled:true
    });
    res.json({ count , Totalcount , paidStudentCount , TotalEnrolled });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});
router.get('/apitest/admin/students/paidlist', async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
    console.log(today)
  try {
    const students = await User.find({
      isPaid:true,

    });
    res.json({ students });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

router.get('/apitest/admin/students/totallist', async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
    console.log(today)
  try {
    const students = await User.find({
      

    });
    res.json({ students });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

///Enrollment Generation Code 

const findCollegeCodeByName = async (collegename) => {
  const college = await NCourse.findOne({ "institute.name": collegename });
  return college ? college.institute.code : null;
};


const findCourseCodeByName = async (coursename) => {
  const course = await NCourse.findOne({ name: coursename });
  return course ? course.code : null;
};

// Function to find branch code by name
const findBranchCodeByName = async (branchname) => {
  const branch = await NCourse.findOne({ "branches.name": branchname });
  return branch ? branch.branches[0].code : null;
};


const CURRENT_YEAR = new Date().getFullYear() % 100;
const NewCurrentYear = CURRENT_YEAR - 1
//onsole.log(NewCurrentYear)
router.post('/api/generate-enrollment2', async (req, res) => {
  const { collegename, coursename, branchname, studentId } = req.body;
  console.log(collegename, coursename, branchname, "Message from Kali ............")
  const level = 3
  const collegeCode = await findCollegeCodeByName(collegename)
  const courseCode = await findCourseCodeByName(coursename)
  const branchCode = await findBranchCodeByName(branchname)
  console.log("data for code ", collegeCode, courseCode, branchCode)
  const currentYearLastTwoDigits = NewCurrentYear.toString().padStart(2, '0');

  try {
    const existingEnrollment = await User.findOne({ _id: studentId, IsEnrollGenerated: true });
    //console.log(existingEnrollment)
    if (existingEnrollment) {
      return res.status(400).json({ error: 'Enrollment already generated for this student' });
    }
    // Find or create enrollment document in the database
    const enrollment = await Enrollment.findOneAndUpdate(
      { collegeCode, courseCode, branchCode, level },
      {},
      { upsert: true, new: true }
    );

    // Increment and save the sequence number
    const sequenceNumber = enrollment.sequenceNumber;
    enrollment.sequenceNumber += 1;
    await enrollment.save();

    // Create and return the enrollment number
    const enrollmentNumber = `${currentYearLastTwoDigits}${collegeCode}${courseCode}${branchCode}${level}${sequenceNumber.toString().padStart(3, '0')}`;
    console.log(enrollmentNumber)
    const updatedStudent = await User.findOneAndUpdate(
      { _id: studentId },
      { randomId: enrollmentNumber, IsEnrollGenerated: true },

      { new: true }
    );

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL,
        pass: process.env.PASSWORD,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL,
      to: updatedStudent.email,
      subject: 'Enrollment Confirmation',
      text: `<div style="font-family: Arial, sans-serif; background-color: #f0f0f0; padding: 20px; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);">
      <h2 style="color: #0077b6;"> <h2 style="color: #0077b6;">Hello ${updatedStudent.name},</h2>,\n\nCongratulations! You have been successfully enrolled in ${collegename} for the ${coursename} - ${branchname} .\n\nYour Enrollment Number is: <b>${enrollmentNumber}</b>\n\nPlease download the enrollment form and submit it to the HOD.\n\nThank you!\nUniversity Administration</div>`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to send enrollment confirmation email' });
      } else {
        console.log('Email sent: ' + info.response);
        res.json({ enrollmentNumber });
      }
    });


  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});










router.post('/api/create-course', async (req, res) => {
  try {
    const { name, code, branches, institute } = req.body;
    // console.log(name , code , "code ")
    // Check if the course with the given code already exists
    const existingCourse = await NCourse.findOne({ coursecode });
    if (existingCourse) {
      return res.status(400).json({ error: 'Course with this code already exists' });
    }

    // Create a new course
    const newCourse = new NCourse({
      coursename,
      coursecode,
      branches,
      institute,
    });

    // Save the new course to the database
    await newCourse.save();

    res.status(201).json({ message: 'Course created successfully', course: newCourse });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

//Masters 





//Routes For Assigning Subject and Schemes 

router.get('/api/admin/masters/assignSubject',(req,res)=>{
  
  
})










module.exports = router