const express = require('express');
const router = express.Router();


router.post('/send-otp',)
router.post('/verify-otp',)



module.exports = router;